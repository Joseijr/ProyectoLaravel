<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\PlantController;

Route::get('/', function () {
    return view('index');
});

Route::get('/', [PlantController::class, 'index'])->name('plants.index');


Route::prefix('courses')->group(function () {

    // Mostrar formulario
    Route::get('/create', [CourseController::class, 'create'])->name('courses.create');

    // Guardar datos
    Route::post('/store', [CourseController::class, 'store'])->name('courses.store');

  
   

});
