<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Cursos</title>

</head>
<!-- Intente ponerle un css como se hace normalmente pero no lo quiere cargar de ninguna forma 
 solo metiendolo dentro del index funciona -->
<style>
   body {
     background: #d7d7d7ff;
    font-family: Arial, sans-serif;
    margin: 30px;
}

h1 {
    text-align: center;
    margin-bottom: 25px;
    color: #333;
}
h3 {
    text-align: center;
    margin-bottom: 25px;
    color: #ff0000ff;
}

.course-card {
     background: #f5f5f5;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;

}
</style>

<body>

  <h1>Lista de Cursos</h1>

   <div class="course-card">
       <h2>Para insertar nuevo curso</h2>
  <p>courses/create</p>
    </div>
  

<?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="course-card">
        <h3><?php echo e($curso->name); ?></h3>
        <p><strong>Codigo:</strong><?php echo e($curso->code); ?></p>
        <p><strong>Categoría:</strong> <?php echo e($curso->category); ?></p>
        <p><strong>Ciclo:</strong> <?php echo e($curso->cycle); ?></p>
        <p><strong>Modalidad:</strong> <?php echo e($curso->modality); ?></p>
        <p><strong>Cupos:</strong> <?php echo e($curso->quota); ?></p>
        <p><strong>Descripción:</strong> <?php echo e($curso->description); ?></p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</body>
</html>
<?php /**PATH C:\laragon\www\lab5\resources\views/index.blade.php ENDPATH**/ ?>