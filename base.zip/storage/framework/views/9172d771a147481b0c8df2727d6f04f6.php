<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Todos los cursos</h1>

<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="margin-bottom: 15px;">
        <h3><?php echo e($course->name); ?></h3>
        <p>Categoría: <?php echo e($course->category); ?></p>
        <p>Ciclo: <?php echo e($course->cycle); ?></p>
        <p>Modalidad: <?php echo e($course->modality); ?></p>
        <p>Cupo: <?php echo e($course->quota); ?></p>
        <p>Descripción: <?php echo e($course->description); ?></p>
    </div>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\laragon\www\lab5\resources\views/list.blade.php ENDPATH**/ ?>