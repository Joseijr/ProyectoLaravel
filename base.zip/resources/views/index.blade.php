<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Plantas</title>
    <style>
       body {
         background: #d7d7d7;
         font-family: Arial, sans-serif;
         margin: 30px;
       }

       h1 {
           text-align: center;
           margin-bottom: 25px;
           color: #333;
       }

       h3 {
           color: #2a7a2a;
           margin-bottom: 10px;
       }

       .plant-card {
           background: #f5f5f5;
           padding: 15px;
           border-radius: 8px;
           margin-bottom: 20px;
       }
    </style>
</head>
<body>

    <h1>Lista de Plantas</h1>

    @foreach ($plants as $plant)
        <div class="plant-card">
            <h3>{{ $plant->name }}</h3>
            <p><strong>Horas de crecimiento:</strong> {{ $plant->growth_hours }}</p>
            <p><strong>Agua necesaria por día:</strong> {{ $plant->water_need_per_day }}</p>
            <p><strong>Efecto del fertilizante:</strong> {{ $plant->fertilizer_effect }}</p>
            <p><strong>Precio:</strong> ${{ $plant->price }}</p>
            <p><strong>Descripción:</strong> {{ $plant->description }}</p>
        </div>
    @endforeach

</body>
</html>
